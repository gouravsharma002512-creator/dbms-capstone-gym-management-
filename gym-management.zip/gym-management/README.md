# Gym Management System

A Python + SQLite command-line application for running a gym: members, membership plans, payments, trainers, class bookings, attendance and reports. No external dependencies.

## Features
- **Members:** add, search, update, delete (unique email validation)
- **Plans & payments:** Monthly / Quarterly / Annual; renewals extend an active plan; every purchase logged as a payment
- **Trainers & classes:** schedule classes with capacity limits
- **Bookings:** only active members can book; prevents double-booking and overbooking; cancellation
- **Attendance:** daily check-in, denied for expired members
- **Reports:** expiring soon, expired, revenue (total or by month), dashboard summary

## Setup
```bash
python main.py --help
python -m unittest discover tests
```

## Quick demo
```bash
python main.py add-member "Asha Rao" asha@example.com --phone 9999999999
python main.py plans
python main.py subscribe 1 monthly
python main.py add-trainer "Ravi" --specialty Yoga
python main.py add-class "Morning Yoga" 1 2026-12-02T07:00 15
python main.py book 1 1
python main.py check-in 1
python main.py summary
python main.py revenue --month 2026-12
```

## Structure
```
main.py           CLI (argparse)
gym/db.py         SQLite schema + default plans
gym/service.py    Business logic (GymService)
tests/test_gym.py Unit tests
```

## Database
Tables: `plans`, `members`, `trainers`, `classes`, `bookings`, `attendance`, `payments` (foreign keys with cascade delete).
