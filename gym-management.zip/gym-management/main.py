"""Command-line interface for the gym management system."""
import argparse
from datetime import date

from gym import GymService
from gym.service import GymError


def table(rows, cols):
    rows = [dict(r) for r in rows]
    if not rows:
        print("(none)")
        return
    w = {c: max(len(c), *(len(str(r.get(c) or "-")) for r in rows)) for c in cols}
    print("  ".join(c.upper().ljust(w[c]) for c in cols))
    for r in rows:
        print("  ".join(str(r.get(c) or "-").ljust(w[c]) for c in cols))


def build_parser():
    p = argparse.ArgumentParser(description="Gym Management System")
    p.add_argument("--db", default="gym.db")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("add-member"); s.add_argument("name"); s.add_argument("email"); s.add_argument("--phone", default="")
    s = sub.add_parser("members"); s.add_argument("--search", default="")
    s = sub.add_parser("update-member"); s.add_argument("id", type=int)
    s.add_argument("--name"); s.add_argument("--email"); s.add_argument("--phone")
    s = sub.add_parser("delete-member"); s.add_argument("id", type=int)
    sub.add_parser("plans")
    s = sub.add_parser("subscribe"); s.add_argument("id", type=int); s.add_argument("plan")
    s = sub.add_parser("add-trainer"); s.add_argument("name"); s.add_argument("--specialty", default="")
    sub.add_parser("trainers")
    s = sub.add_parser("add-class"); s.add_argument("title"); s.add_argument("trainer_id", type=int)
    s.add_argument("start", help="e.g. 2026-12-01T18:00"); s.add_argument("capacity", type=int)
    sub.add_parser("classes")
    s = sub.add_parser("book"); s.add_argument("member_id", type=int); s.add_argument("class_id", type=int)
    s = sub.add_parser("cancel"); s.add_argument("member_id", type=int); s.add_argument("class_id", type=int)
    s = sub.add_parser("check-in"); s.add_argument("member_id", type=int)
    s = sub.add_parser("expiring"); s.add_argument("--days", type=int, default=7)
    sub.add_parser("expired")
    s = sub.add_parser("revenue"); s.add_argument("--month", help="YYYY-MM")
    sub.add_parser("summary")
    return p


def run(a, g):
    c = a.cmd
    if c == "add-member": print("Added member #%d" % g.add_member(a.name, a.email, a.phone))
    elif c == "members": table(g.list_members(a.search), ["id", "name", "email", "phone", "plan", "expires"])
    elif c == "update-member": g.update_member(a.id, name=a.name, email=a.email, phone=a.phone); print("Updated")
    elif c == "delete-member": g.delete_member(a.id); print("Deleted")
    elif c == "plans": table(g.list_plans(), ["name", "duration_days", "price"])
    elif c == "subscribe": print("Active until", g.subscribe(a.id, a.plan))
    elif c == "add-trainer": print("Added trainer #%d" % g.add_trainer(a.name, a.specialty))
    elif c == "trainers": table(g.list_trainers(), ["id", "name", "specialty"])
    elif c == "add-class": print("Added class #%d" % g.add_class(a.title, a.trainer_id, a.start, a.capacity))
    elif c == "classes": table(g.list_classes(), ["id", "title", "trainer", "start", "booked", "capacity"])
    elif c == "book": g.book_class(a.member_id, a.class_id); print("Booked")
    elif c == "cancel": g.cancel_booking(a.member_id, a.class_id); print("Cancelled")
    elif c == "check-in": g.check_in(a.member_id); print("Checked in", date.today())
    elif c == "expiring": table(g.expiring_soon(a.days), ["id", "name", "expires"])
    elif c == "expired": table(g.expired_members(), ["id", "name", "expires"])
    elif c == "revenue": print("Revenue: $%.2f" % g.revenue(a.month))
    elif c == "summary":
        for k, v in g.summary().items(): print(f"{k.replace('_', ' ').title()}: {v}")


if __name__ == "__main__":
    args = build_parser().parse_args()
    try:
        run(args, GymService(args.db))
    except GymError as e:
        raise SystemExit(f"Error: {e}")
