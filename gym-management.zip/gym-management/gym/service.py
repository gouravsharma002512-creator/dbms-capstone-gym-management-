import sqlite3
from datetime import date, datetime, timedelta

from .db import connect


class GymError(Exception):
    pass


class GymService:
    def __init__(self, path="gym.db"):
        self.db = connect(path)

    # ---------- helpers ----------
    @staticmethod
    def _today(today=None):
        return today or date.today()

    def _one(self, sql, args=()):
        return self.db.execute(sql, args).fetchone()

    def _member(self, member_id):
        m = self._one("SELECT * FROM members WHERE id=?", (member_id,))
        if not m:
            raise GymError(f"Member {member_id} not found")
        return m

    # ---------- members ----------
    def add_member(self, name, email, phone="", today=None):
        if not name.strip() or "@" not in email:
            raise GymError("A valid name and email are required")
        try:
            cur = self.db.execute(
                "INSERT INTO members(name,email,phone,joined) VALUES(?,?,?,?)",
                (name.strip(), email.strip().lower(), phone, self._today(today).isoformat()))
        except sqlite3.IntegrityError:
            raise GymError("A member with that email already exists")
        self.db.commit()
        return cur.lastrowid

    def list_members(self, search=""):
        q = f"%{search}%"
        return self.db.execute(
            "SELECT m.*, p.name AS plan FROM members m LEFT JOIN plans p ON p.id=m.plan_id "
            "WHERE m.name LIKE ? OR m.email LIKE ? ORDER BY m.id", (q, q)).fetchall()

    def update_member(self, member_id, **fields):
        self._member(member_id)
        allowed = {k: v for k, v in fields.items() if k in ("name", "email", "phone") and v}
        if not allowed:
            raise GymError("Nothing to update")
        sets = ", ".join(f"{k}=?" for k in allowed)
        self.db.execute(f"UPDATE members SET {sets} WHERE id=?", (*allowed.values(), member_id))
        self.db.commit()

    def delete_member(self, member_id):
        self._member(member_id)
        self.db.execute("DELETE FROM members WHERE id=?", (member_id,))
        self.db.commit()

    # ---------- plans & payments ----------
    def list_plans(self):
        return self.db.execute("SELECT * FROM plans ORDER BY duration_days").fetchall()

    def subscribe(self, member_id, plan_name, today=None):
        """Buy/renew a plan. Renewals extend from the current expiry if still active."""
        m = self._member(member_id)
        plan = self._one("SELECT * FROM plans WHERE name=? COLLATE NOCASE", (plan_name,))
        if not plan:
            raise GymError(f"Unknown plan '{plan_name}'")
        t = self._today(today)
        start = t
        if m["expires"] and date.fromisoformat(m["expires"]) > t:
            start = date.fromisoformat(m["expires"])
        expires = start + timedelta(days=plan["duration_days"])
        self.db.execute("UPDATE members SET plan_id=?, expires=? WHERE id=?",
                        (plan["id"], expires.isoformat(), member_id))
        self.db.execute("INSERT INTO payments(member_id,amount,paid_on,plan_id) VALUES(?,?,?,?)",
                        (member_id, plan["price"], t.isoformat(), plan["id"]))
        self.db.commit()
        return expires

    def is_active(self, member_id, today=None):
        m = self._member(member_id)
        return bool(m["expires"]) and date.fromisoformat(m["expires"]) >= self._today(today)

    # ---------- trainers & classes ----------
    def add_trainer(self, name, specialty=""):
        cur = self.db.execute("INSERT INTO trainers(name,specialty) VALUES(?,?)", (name, specialty))
        self.db.commit()
        return cur.lastrowid

    def list_trainers(self):
        return self.db.execute("SELECT * FROM trainers ORDER BY id").fetchall()

    def add_class(self, title, trainer_id, start, capacity):
        if capacity < 1:
            raise GymError("Capacity must be at least 1")
        if not self._one("SELECT 1 FROM trainers WHERE id=?", (trainer_id,)):
            raise GymError(f"Trainer {trainer_id} not found")
        try:
            datetime.fromisoformat(start)
        except ValueError:
            raise GymError("Start must look like 2026-12-01T18:00")
        cur = self.db.execute("INSERT INTO classes(title,trainer_id,start,capacity) VALUES(?,?,?,?)",
                              (title, trainer_id, start, capacity))
        self.db.commit()
        return cur.lastrowid

    def list_classes(self):
        return self.db.execute(
            "SELECT c.*, t.name AS trainer, "
            "(SELECT COUNT(*) FROM bookings b WHERE b.class_id=c.id) AS booked "
            "FROM classes c JOIN trainers t ON t.id=c.trainer_id ORDER BY c.start").fetchall()

    def book_class(self, member_id, class_id, today=None):
        self._member(member_id)
        c = self._one("SELECT * FROM classes WHERE id=?", (class_id,))
        if not c:
            raise GymError(f"Class {class_id} not found")
        if not self.is_active(member_id, today):
            raise GymError("Membership is not active; please renew first")
        booked = self._one("SELECT COUNT(*) n FROM bookings WHERE class_id=?", (class_id,))["n"]
        if booked >= c["capacity"]:
            raise GymError("Class is full")
        try:
            self.db.execute("INSERT INTO bookings(member_id,class_id) VALUES(?,?)", (member_id, class_id))
        except sqlite3.IntegrityError:
            raise GymError("Already booked into this class")
        self.db.commit()

    def cancel_booking(self, member_id, class_id):
        cur = self.db.execute("DELETE FROM bookings WHERE member_id=? AND class_id=?", (member_id, class_id))
        self.db.commit()
        if cur.rowcount == 0:
            raise GymError("No such booking")

    # ---------- attendance ----------
    def check_in(self, member_id, today=None):
        if not self.is_active(member_id, today):
            raise GymError("Membership expired; check-in denied")
        day = self._today(today).isoformat()
        if self._one("SELECT 1 FROM attendance WHERE member_id=? AND day=?", (member_id, day)):
            raise GymError("Already checked in today")
        self.db.execute("INSERT INTO attendance(member_id,day) VALUES(?,?)", (member_id, day))
        self.db.commit()

    # ---------- reports ----------
    def expiring_soon(self, days=7, today=None):
        t = self._today(today)
        return self.db.execute(
            "SELECT * FROM members WHERE expires BETWEEN ? AND ? ORDER BY expires",
            (t.isoformat(), (t + timedelta(days=days)).isoformat())).fetchall()

    def expired_members(self, today=None):
        return self.db.execute("SELECT * FROM members WHERE expires < ? ORDER BY expires",
                               (self._today(today).isoformat(),)).fetchall()

    def revenue(self, month=None):
        """Total revenue; month as 'YYYY-MM' to filter."""
        if month:
            r = self._one("SELECT COALESCE(SUM(amount),0) s FROM payments WHERE paid_on LIKE ?", (month + "%",))
        else:
            r = self._one("SELECT COALESCE(SUM(amount),0) s FROM payments")
        return r["s"]

    def summary(self, today=None):
        t = self._today(today).isoformat()
        q = lambda sql, a=(): self._one(sql, a)[0]
        return {
            "members": q("SELECT COUNT(*) FROM members"),
            "active": q("SELECT COUNT(*) FROM members WHERE expires >= ?", (t,)),
            "expired": q("SELECT COUNT(*) FROM members WHERE expires < ?", (t,)),
            "check_ins_today": q("SELECT COUNT(*) FROM attendance WHERE day=?", (t,)),
            "total_revenue": self.revenue(),
        }
