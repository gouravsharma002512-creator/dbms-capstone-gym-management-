import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS plans(
    id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL,
    duration_days INTEGER NOT NULL, price REAL NOT NULL);
CREATE TABLE IF NOT EXISTS members(
    id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
    phone TEXT, joined TEXT NOT NULL,
    plan_id INTEGER REFERENCES plans(id), expires TEXT);
CREATE TABLE IF NOT EXISTS trainers(
    id INTEGER PRIMARY KEY, name TEXT NOT NULL, specialty TEXT);
CREATE TABLE IF NOT EXISTS classes(
    id INTEGER PRIMARY KEY, title TEXT NOT NULL,
    trainer_id INTEGER REFERENCES trainers(id),
    start TEXT NOT NULL, capacity INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS bookings(
    id INTEGER PRIMARY KEY,
    member_id INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
    class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
    UNIQUE(member_id, class_id));
CREATE TABLE IF NOT EXISTS attendance(
    id INTEGER PRIMARY KEY,
    member_id INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
    day TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS payments(
    id INTEGER PRIMARY KEY,
    member_id INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
    amount REAL NOT NULL, paid_on TEXT NOT NULL, plan_id INTEGER);
"""

DEFAULT_PLANS = [("Monthly", 30, 40.0), ("Quarterly", 90, 105.0), ("Annual", 365, 380.0)]


def connect(path="gym.db"):
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(SCHEMA)
    if not conn.execute("SELECT 1 FROM plans").fetchone():
        conn.executemany("INSERT INTO plans(name,duration_days,price) VALUES(?,?,?)", DEFAULT_PLANS)
    conn.commit()
    return conn
