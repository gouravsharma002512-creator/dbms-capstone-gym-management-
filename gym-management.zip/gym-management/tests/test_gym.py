import os, sys, unittest
from datetime import date, timedelta
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from gym import GymService
from gym.service import GymError

T = date(2026, 12, 1)


class GymTests(unittest.TestCase):
    def setUp(self):
        self.g = GymService(":memory:")
        self.m = self.g.add_member("Asha", "asha@example.com", today=T)
        self.t = self.g.add_trainer("Ravi", "Yoga")
        self.c = self.g.add_class("Morning Yoga", self.t, "2026-12-02T07:00", 1)

    def test_duplicate_email(self):
        with self.assertRaises(GymError):
            self.g.add_member("Other", "ASHA@example.com")

    def test_subscribe_and_active(self):
        exp = self.g.subscribe(self.m, "monthly", today=T)
        self.assertEqual(exp, T + timedelta(days=30))
        self.assertTrue(self.g.is_active(self.m, T))
        self.assertFalse(self.g.is_active(self.m, T + timedelta(days=31)))

    def test_renewal_extends_active_plan(self):
        self.g.subscribe(self.m, "Monthly", today=T)
        exp = self.g.subscribe(self.m, "Monthly", today=T + timedelta(days=10))
        self.assertEqual(exp, T + timedelta(days=60))

    def test_booking_rules(self):
        with self.assertRaises(GymError):          # no plan yet
            self.g.book_class(self.m, self.c, today=T)
        self.g.subscribe(self.m, "Monthly", today=T)
        self.g.book_class(self.m, self.c, today=T)
        with self.assertRaises(GymError):          # duplicate
            self.g.book_class(self.m, self.c, today=T)
        m2 = self.g.add_member("Bo", "bo@example.com")
        self.g.subscribe(m2, "Monthly", today=T)
        with self.assertRaises(GymError):          # full
            self.g.book_class(m2, self.c, today=T)
        self.g.cancel_booking(self.m, self.c)
        self.g.book_class(m2, self.c, today=T)

    def test_check_in(self):
        with self.assertRaises(GymError):
            self.g.check_in(self.m, T)
        self.g.subscribe(self.m, "Monthly", today=T)
        self.g.check_in(self.m, T)
        with self.assertRaises(GymError):
            self.g.check_in(self.m, T)

    def test_revenue_and_reports(self):
        self.g.subscribe(self.m, "Monthly", today=T)
        self.g.subscribe(self.m, "Annual", today=T)
        self.assertEqual(self.g.revenue("2026-12"), 420.0)
        self.assertEqual(self.g.revenue("2026-11"), 0)
        self.assertEqual(self.g.summary(T)["active"], 1)
        self.assertEqual(len(self.g.expired_members(T + timedelta(days=500))), 1)

    def test_delete_cascades(self):
        self.g.subscribe(self.m, "Monthly", today=T)
        self.g.delete_member(self.m)
        self.assertEqual(self.g.revenue(), 0)


if __name__ == "__main__":
    unittest.main()
